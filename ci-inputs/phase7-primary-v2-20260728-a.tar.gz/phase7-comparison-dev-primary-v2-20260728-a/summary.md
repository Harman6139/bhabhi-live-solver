# Phase 7 Paired Comparison

- Run: `phase7-comparison-dev-primary-v2-20260728-a`
- Run kind: `development-primary`
- Split: `dev`
- Evidence eligible: no
- Attempted/completed/expected games: 408 / 408 / 408
- Recorded failures: 0
- Silent exclusions: 0
- Complete paired base-cell-rotation units: 204 / 204
- Candidate minus reference paired macro interval: 0.000000 [0.000000, 0.000000]
- Scientific digest: `sha256:4c9dfc7ae9ee15bba5e9a75b2883675adf2c1568b06eeba6cdd6503b1ff4d75f`
- Rerun equality: not claimed by an individual run; requires the cross-artifact attestation

This is development evidence only and is never production-enable evidence.

| Role | Config | Games | Failures | User Bhabhi rate | Exact uses | Typed refusals |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| reference | phase5-balanced-hard-only-reference-v1 | 204 | 0 | 17.16% | 0 | 0 |
| candidate | phase7-exact-then-phase5-fallback-v1 | 204 | 0 | 17.16% | 52 | 4275 |
